#include "wifi_board.h"
#include "codecs/no_audio_codec.h"
#include "display/oled_display.h"
#include "application.h"
#include "button.h"
#include "config.h"
#include "mcp_server.h"

#include <driver/i2c_master.h>
#include <driver/ledc.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_panel_vendor.h>
#include <esp_log.h>
#include <freertos/task.h>
#include <algorithm>
#include <cmath>

#define TAG "ArthurRobot"

class ServoDriver {
private:
    static constexpr ledc_mode_t kSpeedMode = LEDC_LOW_SPEED_MODE;
    static constexpr ledc_timer_t kTimer = LEDC_TIMER_0;
    static constexpr ledc_channel_t kChannel = LEDC_CHANNEL_0;
    static constexpr ledc_timer_bit_t kDutyResolution = LEDC_TIMER_13_BIT;
    static constexpr int kFrequencyHz = 50;
    static constexpr int kMinPulseUs = 500;
    static constexpr int kMaxPulseUs = 2500;

    gpio_num_t gpio_;
    bool initialized_ = false;

    uint32_t DutyFromAngle(int angle) const {
        angle = std::clamp(angle, 0, 180);
        const int pulse_us = kMinPulseUs + (kMaxPulseUs - kMinPulseUs) * angle / 180;
        const uint32_t duty_max = (1u << kDutyResolution) - 1u;
        return (static_cast<uint64_t>(pulse_us) * duty_max) / 20000u;
    }

public:
    explicit ServoDriver(gpio_num_t gpio) : gpio_(gpio) {
        ledc_timer_config_t timer_cfg = {};
        timer_cfg.speed_mode = kSpeedMode;
        timer_cfg.timer_num = kTimer;
        timer_cfg.duty_resolution = kDutyResolution;
        timer_cfg.freq_hz = kFrequencyHz;
        timer_cfg.clk_cfg = LEDC_AUTO_CLK;
        ESP_ERROR_CHECK(ledc_timer_config(&timer_cfg));

        ledc_channel_config_t channel_cfg = {};
        channel_cfg.gpio_num = gpio_;
        channel_cfg.speed_mode = kSpeedMode;
        channel_cfg.channel = kChannel;
        channel_cfg.timer_sel = kTimer;
        channel_cfg.duty = 0;
        channel_cfg.hpoint = 0;
        ESP_ERROR_CHECK(ledc_channel_config(&channel_cfg));
        initialized_ = true;
    }

    void SetAngle(int angle) {
        if (!initialized_) {
            return;
        }
        const uint32_t duty = DutyFromAngle(angle);
        ESP_ERROR_CHECK(ledc_set_duty(kSpeedMode, kChannel, duty));
        ESP_ERROR_CHECK(ledc_update_duty(kSpeedMode, kChannel));
    }
};

class ArthurRobot : public WifiBoard {
private:
    Button boot_button_;
    Display* display_ = nullptr;
    i2c_master_bus_handle_t i2c_bus_ = nullptr;
    esp_lcd_panel_io_handle_t panel_io_ = nullptr;
    esp_lcd_panel_handle_t panel_ = nullptr;
    ServoDriver servo1_{SERVO_LEFT_ARM_GPIO};

    void InitializeI2c() {
        i2c_master_bus_config_t bus_config = {
            .i2c_port = I2C_NUM_0,
            .sda_io_num = I2C_SDA_PIN,
            .scl_io_num = I2C_SCL_PIN,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .intr_priority = 0,
            .trans_queue_depth = 0,
            .flags = {
                .enable_internal_pullup = 1,
            },
        };
        ESP_ERROR_CHECK(i2c_new_master_bus(&bus_config, &i2c_bus_));
    }

    void InitializeDisplay() {
        uint8_t display_address = 0;
        for (const uint8_t address : {0x3C, 0x3D}) {
            if (i2c_master_probe(i2c_bus_, address, 50) == ESP_OK) {
                display_address = address;
                break;
            }
        }
        if (display_address == 0) {
            ESP_LOGW(TAG, "SSD1306 not detected at 0x3C or 0x3D; continuing without display");
            return;
        }

        esp_lcd_panel_io_i2c_config_t io_config = {};
        io_config.dev_addr = display_address;
        io_config.scl_speed_hz = 400 * 1000;
        io_config.control_phase_bytes = 1;
        io_config.dc_bit_offset = 6;
        io_config.lcd_cmd_bits = 8;
        io_config.lcd_param_bits = 8;
        esp_err_t err = esp_lcd_new_panel_io_i2c(i2c_bus_, &io_config, &panel_io_);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Failed to create SSD1306 I2C interface: %s", esp_err_to_name(err));
            return;
        }

        esp_lcd_panel_ssd1306_config_t ssd1306_config = {
            .height = DISPLAY_HEIGHT,
        };
        esp_lcd_panel_dev_config_t panel_config = {};
        panel_config.reset_gpio_num = GPIO_NUM_NC;
        panel_config.bits_per_pixel = 1;
        panel_config.vendor_config = &ssd1306_config;
        err = esp_lcd_new_panel_ssd1306(panel_io_, &panel_config, &panel_);
        if (err == ESP_OK) {
            err = esp_lcd_panel_reset(panel_);
        }
        if (err == ESP_OK) {
            err = esp_lcd_panel_init(panel_);
        }
        if (err == ESP_OK) {
            err = esp_lcd_panel_disp_on_off(panel_, true);
        }
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Failed to initialize SSD1306 at 0x%02X: %s", display_address,
                     esp_err_to_name(err));
            if (panel_ != nullptr) {
                esp_lcd_panel_del(panel_);
                panel_ = nullptr;
            }
            esp_lcd_panel_io_del(panel_io_);
            panel_io_ = nullptr;
            return;
        }

        display_ = new OledDisplay(panel_io_, panel_, DISPLAY_WIDTH, DISPLAY_HEIGHT,
                                   DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y);
    }

    void InitializeButton() {
        boot_button_.OnClick([this]() {
            auto& app = Application::GetInstance();
            if (app.GetDeviceState() == kDeviceStateStarting) {
                EnterWifiConfigMode();
                return;
            }
            RunSpeakerTest();
        });
    }

    void InitializeTools() {
        auto& mcp_server = McpServer::GetInstance();
        mcp_server.AddTool("self.servo1.set_angle",
            "Move servo1 to an absolute angle in degrees. Use this for the robot's first servo test. "
            "Angle range: 0 to 180.",
            PropertyList({
                Property("angle", kPropertyTypeInteger, 0, 180)
            }),
            [this](const PropertyList& properties) -> ReturnValue {
                int angle = properties["angle"].value<int>();
                ESP_LOGI(TAG, "Set servo1 angle to %d", angle);
                servo1_.SetAngle(angle);
                return true;
            });

        mcp_server.AddTool("self.servo1.home",
            "Move servo1 to the neutral 90 degree position.",
            PropertyList(),
            [this](const PropertyList&) -> ReturnValue {
                ESP_LOGI(TAG, "Home servo1 to 90 degrees");
                servo1_.SetAngle(90);
                return true;
            });
    }

    void RunSpeakerTest() {
        auto* codec = GetAudioCodec();
        xTaskCreate([](void* arg) {
            auto* codec = static_cast<AudioCodec*>(arg);
            constexpr int sample_rate = AUDIO_OUTPUT_SAMPLE_RATE;
            constexpr int block_samples = 240;
            constexpr float frequency = 1000.0f;
            std::vector<int16_t> samples(block_samples);
            codec->SetOutputVolume(60);
            codec->EnableOutput(true);
            ESP_LOGI(TAG, "Speaker test: 1 kHz tone for 3 seconds");
            for (int block = 0; block < sample_rate * 3 / block_samples; ++block) {
                for (int i = 0; i < block_samples; ++i) {
                    float phase = 2.0f * static_cast<float>(M_PI) * frequency * (block * block_samples + i) / sample_rate;
                    samples[i] = static_cast<int16_t>(12000.0f * std::sin(phase));
                }
                codec->OutputData(samples);
            }
            codec->EnableOutput(false);
            ESP_LOGI(TAG, "Speaker test complete");
            vTaskDelete(nullptr);
        }, "speaker_test", 4096, codec, 5, nullptr);
    }

    void RunMicTest() {
        auto* codec = GetAudioCodec();
        xTaskCreate([](void* arg) {
            auto* codec = static_cast<AudioCodec*>(arg);
            std::vector<int16_t> samples(240);
            codec->EnableInput(true);
            ESP_LOGI(TAG, "Microphone test: speak near the mic for 10 seconds");
            for (int block = 0; block < 667; ++block) {
                if (!codec->InputData(samples)) {
                    ESP_LOGW(TAG, "Microphone read failed");
                    continue;
                }
                int peak = 0;
                long long sum = 0;
                for (int16_t sample : samples) {
                    int value = sample < 0 ? -sample : sample;
                    if (value > peak) peak = value;
                    sum += value;
                }
                if ((block % 20) == 0) {
                    ESP_LOGI(TAG, "MIC peak=%d average=%d", peak,
                             static_cast<int>(sum / samples.size()));
                }
            }
            codec->EnableInput(false);
            ESP_LOGI(TAG, "Microphone test complete");
            vTaskDelete(nullptr);
        }, "mic_test", 4096, codec, 5, nullptr);
    }

public:
    ArthurRobot() : boot_button_(BOOT_BUTTON_GPIO) {
        InitializeI2c();
        InitializeDisplay();
        InitializeButton();
        InitializeTools();
        servo1_.SetAngle(90);
        ESP_LOGI(TAG, "Arthur robot board initialized");
    }

    AudioCodec* GetAudioCodec() override {
        static NoAudioCodecDuplex audio_codec(
            AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_GPIO_BCLK, AUDIO_I2S_GPIO_WS,
            AUDIO_I2S_GPIO_DOUT, AUDIO_I2S_GPIO_DIN);
        return &audio_codec;
    }

    Display* GetDisplay() override {
        return display_ != nullptr ? display_ : Board::GetDisplay();
    }

    i2c_master_bus_handle_t GetI2cBus() const {
        return i2c_bus_;
    }
};

DECLARE_BOARD(ArthurRobot);
